﻿using FHSquareLibrary.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FHSquareLibrary.Repos
{
    public class EFCartRepo : ICartRepo
    {
        FHSquareContextDB ctx = new FHSquareContextDB();
        public async Task AddToCart(Cart cart)
        {
            ctx.Carts.Add(cart);
            await ctx.SaveChangesAsync();
        }

        public async Task ClearCart(string userName)
        {
            List<Cart> carts = await GetCartByUserName(userName);
            ctx.Carts.RemoveRange(carts);
            await ctx.SaveChangesAsync();
        }

        public async Task<Cart> GetCartById(int cartId)
        {
            try
            {
                Cart cart = await (from cr in ctx.Carts where cr.CartId == cartId select cr).FirstAsync();
                return cart;
            }
            catch(Exception) 
            {
                throw new Exception("No cart for this ID");
            }
        }

        public async Task<List<Cart>> GetCartByUserName(string userName)
        {
            List<Cart> carts = await ctx.Carts.ToListAsync();
            return carts;
        }

        public async Task RemoveFromCart(int cartId)
        {
            Cart cart = await GetCartById(cartId);
            ctx.Carts.Remove(cart);
            await ctx.SaveChangesAsync();
        }

        public async Task UpdateCart(Cart cart)
        {
             Cart cr = await GetCartById(cart.CartId);
             cr.Quantity = cart.Quantity;
             await ctx.SaveChangesAsync();
        }
    }
}
